﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class UserTask
    {
        /// <summary>
        /// Represent user identity
        /// </summary>
        public int AccountId { get; set; }

        /// <summary>
        /// User Name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// List of task of the user
        /// </summary>
        public List<TaskData> TaskDetails { get; set; }
    }
}
