﻿using System;

namespace TaskRepository
{
    public class Class1
    {
    }
}
