﻿using DAL.DALModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public interface ITaskManagement
    {
        /// <summary>
        /// Get all task details
        /// </summary>
        /// <returns></returns>
        List<TaskData> GetTaskDetails();

        /// <summary>
        /// Get Task details by task id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>list of taskdata</returns>
        TaskData GetTaskDetailsById(int Id);

        /// <summary>
        /// Add Task Details
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        void AddTask(TaskData taskInfo);

        /// <summary>
        /// update task by task id
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        void UpdateTask(TaskData taskInfo);

        /// <summary>
        /// Delete task by task id
        /// </summary>
        /// <param name="taskId">task id</param>
        void DeleteTask(int taskId);
        
    }
}
