﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DAL.DALModel;
using System.IO;
using DAL;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TODOApp.ApiController
{


    [Route("api/[controller]")]
    [ApiController]
    public class UserTaskController : ControllerBase
    {
        private TaskRepository _taskManagement;
        public UserTaskController(TaskRepository taskManagement)
        {
            _taskManagement = taskManagement;
        }
        // GET: api/<UserTaskController>
        [HttpGet]
        public List<TaskData> Get()
        {
            try
            {
                return _taskManagement.GetTaskDetails();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        // GET api/<UserTaskController>/5
        [HttpGet("{id}")]
        public TaskData Get(int id)
        {
            try
            {
                return _taskManagement.GetTaskDetailsById(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // POST api/<UserTaskController>
        [HttpPost]
        public void Post([FromBody] TaskData value)
        {
            try
            {
                _taskManagement.AddTask(value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // PUT api/<UserTaskController>/5
        [HttpPut("{id}")]
        public void Put([FromBody] TaskData value)
        {
            try
            {
                _taskManagement.UpdateTask(value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // DELETE api/<UserTaskController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            try
            {
                _taskManagement.DeleteTask(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
