﻿using DAL.DALModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAL
{
    public class TaskManagement : ITaskManagement
    {
        // private static readonly TaskManagementSingleTon _instance = new TaskManagementSingleTon();

        public static List<UserTask> taskDetails = null;

        public TaskManagement()
        {
            taskDetails = new List<UserTask>()
            {
             new UserTask{ AccountId =1, UserName="abc", TaskDetails = new List<TaskData>
            {
                new TaskData
                {
                     TaskId = 1,
                     TaskName= "Huddle Meeting",
                     TaskDescription= "Daily Scrum update",
                     TaskStatus= TaskStatus.NotStarted,
                     CreateDate =DateTime.Now.AddDays(-1),
                     EffectiveDate = DateTime.Now,
                }
            }
        },
             new UserTask
        {
            AccountId = 2,
            UserName = "xyz",
            TaskDetails = new List<TaskData>
            {
                new TaskData
                {
                     TaskId = 2,
                     TaskName= "Design Review",
                     TaskDescription= "Code reviews and design review",
                     TaskStatus= TaskStatus.Completed,
                     CreateDate =DateTime.Now.AddDays(-1),
                     EffectiveDate = DateTime.Now,
                }
            }
        }
            };
        }

        //// public static TaskManagementSingleTon InStance
        // {
        //     get
        //     {
        //         return _instance;
        //     }
        // }

        /// <summary>
        /// Get all task details
        /// </summary>
        /// <returns></returns>
        public List<TaskData> GetTaskDetails()
        {
            //User id will be coming from identity
            var list = taskDetails.Where(x => x.AccountId == 1).FirstOrDefault();
            return list?.TaskDetails;
        }

        /// <summary>
        /// Get Task details by task id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>list of taskdata</returns>
        public TaskData GetTaskDetailsById(int Id)
        {
            //User id will be coming from identity
            var list = taskDetails.Where(x => x.AccountId == 1).FirstOrDefault();
            return list?.TaskDetails.Where(x => x.TaskId == Id).FirstOrDefault();
        }

        /// <summary>
        /// Add Task Details
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        public void AddTask(TaskData taskInfo)
        {
            //User account info come from identity
            taskDetails.Add(new UserTask
            {
                AccountId = 1,
                TaskDetails = new List<TaskData>
                { new TaskData
                {
                    TaskId = GetMaxTaskId(),
                    TaskName = taskInfo.TaskName,
                    TaskDescription = taskInfo.TaskDescription,
                    TaskStatus = TaskStatus.NotStarted,
                    CreateDate = DateTime.Now,
                    EffectiveDate = taskInfo.EffectiveDate
                }
                }
            });
        }

        /// <summary>
        /// update task by task id
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        public void UpdateTask(TaskData taskInfo)
        {
            var list = taskDetails.Where(x => x.AccountId == 1).FirstOrDefault();
            TaskData task = list.TaskDetails.Where(x => x.TaskId == taskInfo.TaskId).FirstOrDefault();
            //TODO: need to validate
            task.TaskId = taskInfo.TaskId;
            task.TaskName = taskInfo.TaskName;
            task.TaskDescription = taskInfo.TaskDescription;
            task.TaskStatus = TaskStatus.NotStarted;
            task.CreateDate = DateTime.Now;
            task.EffectiveDate = taskInfo.EffectiveDate;
            //User account info come from identity

        }

        /// <summary>
        /// Delete task by task id
        /// </summary>
        /// <param name="taskId">task id</param>
        public void DeleteTask(int taskId)
        {
            var list = taskDetails.Where(x => x.AccountId == 1).FirstOrDefault();
            TaskData task = list.TaskDetails.Where(x => x.TaskId == taskId).FirstOrDefault();

            //TODO: Need to validate
            taskDetails.Where(x => x.AccountId == 1).FirstOrDefault()?.TaskDetails.Remove(task);
        }


        /// <summary>
        /// returning max taskid number to give unique task id for each created task
        /// </summary>
        /// <returns></returns>
        private int GetMaxTaskId()
        {
            int maxTaskId = 0;
            foreach (var userTask in taskDetails)
            {
                maxTaskId = userTask.TaskDetails.OrderByDescending(x => x.TaskId).FirstOrDefault().TaskId;

            }
            return maxTaskId;
        }
    }
}
