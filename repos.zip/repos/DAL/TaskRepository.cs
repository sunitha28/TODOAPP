﻿using DAL.DALModel;
using System;
using System.Collections.Generic;

namespace DAL
{
    public class TaskRepository
    {
        private ITaskManagement _taskManagement;
        public TaskRepository(ITaskManagement taskManagement)
        {
            _taskManagement = taskManagement;
        }

        /// <summary>
        /// Get all task details
        /// </summary>
        /// <returns></returns>
        public List<TaskData> GetTaskDetails()
        {
            return _taskManagement.GetTaskDetails();
        }
        /// <summary>
        /// Get Task details by task id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>list of taskdata</returns>
        public TaskData GetTaskDetailsById(int Id)
        {
            return _taskManagement.GetTaskDetailsById(Id);
        }

        /// <summary>
        /// Add Task Details
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        public void AddTask(TaskData taskInfo)
        {
            _taskManagement.AddTask(taskInfo);
        }

        /// <summary>
        /// update task by task id
        /// </summary>
        /// <param name="taskInfo">taskInfo</param>
        public void UpdateTask(TaskData taskInfo)
        {
            _taskManagement.UpdateTask(taskInfo);
        }

        /// <summary>
        /// Delete task by task id
        /// </summary>
        /// <param name="taskId">task id</param>
        public void DeleteTask(int taskId)
        {
            _taskManagement.DeleteTask(taskId);
        }
    }
}
