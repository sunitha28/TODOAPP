﻿using System;

namespace DAL.DALModel
{
    /// <summary>
    /// Status Task
    /// </summary>
    public enum TaskStatus
    {
        NotStarted =1,

        InProgress =2,

        Completed =3
    }
    public class TaskData
    {
        /// <summary>
        /// Unique identifier of task
        /// </summary>
        public int TaskId { get; set; }

        /// <summary>
        /// Task Name
        /// </summary>
        public string TaskName { get; set; }

        /// <summary>
        /// Task Description 
        /// </summary>
        public string TaskDescription { get; set; }

        /// <summary>
        /// Refers Task Status
        /// </summary>
        public TaskStatus TaskStatus { get; set; }

        /// <summary>
        /// Created Date
        /// </summary>
        public DateTime CreateDate { get; set; }

        /// <summary>
        /// Effective Date
        /// </summary>
        public DateTime EffectiveDate { get; set; }

        //public string TaskFrequency { get; set; }
    }
}