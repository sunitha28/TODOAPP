using Microsoft.VisualStudio.TestTools.UnitTesting;
using TODOApp.ApiController;
using DAL.DALModel;
using System.Collections.Generic;
using System.Linq;

namespace ToDo.Test
{
    [TestClass]
    public class UserTaskControllerTest
    {
        private DAL.TaskRepository _taskRepo;

        private DAL.ITaskManagement _taskManagement;
        public UserTaskControllerTest()
        {
        }
        public UserTaskControllerTest(DAL.ITaskManagement taskManagement, DAL.TaskRepository taskRepo)
        {
            _taskManagement = taskManagement;
            _taskRepo = new DAL.TaskRepository(_taskManagement);
        }
        [TestMethod]
        public void GetAllTasksTest()
        {
            UserTaskController task = new UserTaskController(_taskRepo);
            List<TaskData> taskData = task.Get();
            Assert.IsNotNull(taskData);
        }

        [TestMethod]
        public void GetAllTasksTestById()
        {
            UserTaskController task = new UserTaskController(_taskRepo);
            TaskData taskData = task.Get(1);
            Assert.IsNotNull(taskData);
        }

        [TestMethod]
        public void GetAllTasksTestById_NotExist()
        {
            UserTaskController task = new UserTaskController(_taskRepo);
            TaskData taskData = task.Get(0);
            Assert.IsNull(taskData);
        }

        [TestMethod]
        public void AddTask()
        {
            TaskData taskData = new TaskData()
            {
                TaskName = "Adding Task Test",
                TaskDescription = "Test Task",
                TaskStatus = TaskStatus.NotStarted
            };
            UserTaskController task = new UserTaskController(_taskRepo);
            task.Post(taskData);
            List<TaskData> latestTask = task.Get();
            bool isTaskAvailable = latestTask.Any(x => x.TaskName == "Adding Task Test");
            Assert.IsTrue(isTaskAvailable);
        }

        [TestMethod]
        public void UpdateTaskStatus_Test()
        {
            TaskData taskData = new TaskData()
            {
                TaskId = 1,
                TaskName = "Modified task Test",
                TaskDescription = "Test Task",
                TaskStatus = TaskStatus.InProgress
            };

            UserTaskController task = new UserTaskController(_taskRepo);
            TaskData prevTask = task.Get(1);
            task.Put(taskData);
            TaskData latestTask = task.Get(1);
            Assert.AreNotEqual(prevTask.TaskStatus, latestTask.TaskStatus);
        }

        [TestMethod]
        public void Delete_Test()
        {
            UserTaskController task = new UserTaskController(_taskRepo);
            task.Delete(1);
            List<TaskData> latestTask = task.Get();
            bool isTaskAvailable = latestTask.Any(x => x.TaskId == 1);
            Assert.IsFalse(isTaskAvailable);
        }
    }
}
